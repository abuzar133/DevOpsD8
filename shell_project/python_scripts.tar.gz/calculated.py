def add(a,b):
    return a+b
sum_of_num = add(2,3)
print(f"The result of addition is: {sum_of_num}")

