print("Hello,world!! This is the first python script.")


